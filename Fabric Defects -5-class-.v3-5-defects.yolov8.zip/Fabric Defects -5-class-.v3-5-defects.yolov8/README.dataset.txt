# Fabric Defects (5-class) > 5 defects
https://universe.roboflow.com/jaswant-oyc4f/fabric-defects-5-class-b2mwz

Provided by a Roboflow user
License: CC BY 4.0

